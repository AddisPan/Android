package com.example.a123456789;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity3 extends AppCompatActivity {
    EditText etfirst, etSecond;
    Button btnGo;
    WebView wv2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        etfirst = (EditText) findViewById(R.id.etFirst);
        etSecond = (EditText) findViewById(R.id.etSecond);
        btnGo = (Button) findViewById(R.id.btnGo);
        wv2 = (WebView) findViewById(R.id.webview2);
        wv2.getSettings().setJavaScriptEnabled(true);
        btnGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                wv2.loadUrl("https://www.google.com.tw/maps/dir/"+etfirst.getText().toString()
                        +"/"+etSecond.getText().toString()+"/花蓮巿/");
            }
        });
    }
}