package com.example.a123456789_listview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class StringArrayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_string_array);
    }
}