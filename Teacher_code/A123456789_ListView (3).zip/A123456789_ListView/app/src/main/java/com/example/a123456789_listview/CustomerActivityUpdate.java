package com.example.a123456789_listview;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class CustomerActivityUpdate extends AppCompatActivity {
    ArrayList<HashMap<String, String>> arylist;
    LinearLayout ll;
    int iSelectIndex = 0 ;
    ImageView iSelectImageView ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_update);
        arylist = (ArrayList<HashMap<String, String>>) getIntent().getSerializableExtra("data");
        InitialUI();
    }

    private void InitialUI() {
        ScrollView sv = new ScrollView(this);
        this.addContentView(sv, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.MATCH_PARENT));
        ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        sv.addView(ll,new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT));

        reloadUI();
    }

    public void getSelected(int i){
        Toast.makeText(getApplicationContext(), ImageDialogFragment.ipic[i], Toast.LENGTH_SHORT).show();
        arylist.get(iSelectIndex).put("pic",String.valueOf(ImageDialogFragment.ipic[i]));
        iSelectImageView.setImageResource(ImageDialogFragment.ipic[i]);
//        if (ll.getChildAt(i) instanceof LinearLayout){
//            Log.v("test", "11");
//            LinearLayout ll2 = (LinearLayout)ll.getChildAt(i);
//            if (ll2.getChildAt(2) instanceof ImageView){
//                Log.v("test", "22");
//                ImageView iv = (ImageView) ll2.getChildAt(2);
//                Log.v("test", "33");
//                iv.setImageResource(R.drawable.a1);
//                Log.v("test", "44");
//            }
//        }
    }


    @Override
    public void onBackPressed() {
        for(int i=0 ; i < arylist.size(); i++){
            arylist.get(i).put("name",((EditText)((LinearLayout)ll.getChildAt(i)).getChildAt(0)).getText().toString());
            arylist.get(i).put("price",((EditText)((LinearLayout)ll.getChildAt(i)).getChildAt(1)).getText().toString());
        }
        getIntent().putExtra("Result", arylist);
        setResult(996,getIntent());
        super.onBackPressed();
    }

    public void reloadUI(){
        ll.removeAllViews();
        for(int i = 0; i< arylist.size(); i++){
            LinearLayout ll2 = new LinearLayout(this);
            ll2.setOrientation(LinearLayout.HORIZONTAL);
            ll.addView(ll2, new ViewGroup.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    150));
            ll2.setWeightSum(10);

            EditText et = new EditText(this);
            et.setGravity(Gravity.CENTER);
            et.setText(arylist.get(i).get("name"));
            ll2.addView(et, new LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.MATCH_PARENT, 3));

            et = new EditText(this);
            et.setGravity(Gravity.CENTER);
            et.setText(arylist.get(i).get("price"));
            ll2.addView(et, new LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.MATCH_PARENT, 3));

            ImageView iv = new ImageView(this);
            iv.setImageResource(Integer.parseInt(arylist.get(i).get("pic")));
            ll2.addView(iv, new LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.MATCH_PARENT, 3));
            iv.setOnClickListener(new ClassImageViewChoice(i));

            Button btndel = new Button(this);
            btndel.setText("Del");
            ll2.addView(btndel, new LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.MATCH_PARENT, 1));
            btndel.setOnClickListener(new ClassButtonDel(i));
        }

        Button btnAdd = new Button(this);
        btnAdd.setGravity(Gravity.CENTER);
        btnAdd.setText("新增");
        ll.addView(btnAdd, new ViewGroup.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LinearLayout ll2 = new LinearLayout(getApplicationContext());
                ll2.setOrientation(LinearLayout.HORIZONTAL);
                ll.addView(ll2, arylist.size() ,new ViewGroup.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        150));
                ll2.setWeightSum(10);

                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("name", "");
                hashMap.put("price","");
                hashMap.put("pic",String.valueOf(R.drawable.ic_launcher_background));
                arylist.add(hashMap);

                EditText et = new EditText(getApplicationContext());
                et.setGravity(Gravity.CENTER);
                et.setText("");
                ll2.addView(et, new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT, 3));

                et = new EditText(getApplicationContext());
                et.setGravity(Gravity.CENTER);
                et.setText("");
                ll2.addView(et, new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT, 3));

                ImageView iv = new ImageView(getApplicationContext());
                iv.setImageResource(R.drawable.ic_launcher_background);
                ll2.addView(iv, new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT, 3));
                iv.setOnClickListener(new ClassImageViewChoice(arylist.size()-1));

                Button btndel = new Button(getApplicationContext());
                btndel.setText("Del");
                ll2.addView(btndel, new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT, 1));
                btndel.setOnClickListener(new ClassButtonDel(arylist.size()-1));

            }
        });
    }

    class ClassImageViewChoice implements View.OnClickListener {
        int position;
        ClassImageViewChoice(int _position){
            position = _position;
        }
        @Override
        public void onClick(View v) {
            iSelectIndex = position;
            iSelectImageView = (ImageView) v;
            (new ImageDialogFragment()).show(getSupportFragmentManager(), "abc");
        }
    }



    class ClassButtonDel implements View.OnClickListener{
        int position;
        ClassButtonDel(int _position){
            position = _position;
        }

        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), arylist.get(position).get("name"), Toast.LENGTH_SHORT).show();
            AlertDialog.Builder builder = new AlertDialog.Builder(CustomerActivityUpdate.this);
            builder.setMessage("確定刪除這筆資料 ?").setPositiveButton("確定", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    arylist.remove(position);
//                    reloadUI();
                    ll.removeViewAt(position);
                }
            }).setNegativeButton("取消", null).show();
        }
    }

}