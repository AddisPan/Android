package com.example.a123456789_readwritefile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnTxt, btnObject, btnSP, btnSPbase64, btnGson;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnTxt = (Button) findViewById(R.id.btntxt);
        btnObject = (Button) findViewById(R.id.btnObject);
        btnSP = (Button) findViewById(R.id.btnSP);
        btnSPbase64 = (Button) findViewById(R.id.btnSPBase64);
        btnGson = (Button) findViewById(R.id.btnGson);
        btnTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), TxtActivity.class));
            }
        });
        btnObject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), ObjectActivity.class));
            }
        });
        btnSP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), SPActivity.class));
            }
        });
        btnSPbase64.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), SPbase64Activity.class));
            }
        });
        btnGson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), GsonActivity.class));
            }
        });
    }
}