package com.example.a123456789_android_internet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

public class ImageWebActivity extends AppCompatActivity {
    ImageView iv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_web);
        iv = (ImageView) findViewById(R.id.ivWebImage);
        String strurl = "https://cdn.hk01.com/di/media/images/cis/5dce4b78b66f770df1c125a4.jpg/Tgxeop6-37mrSiQzpBO_fxt7SebzSexgCK2vTwitr08?v=w1920";
        Glide.with(this).load(strurl).into(iv);
    }
}