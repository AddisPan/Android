package com.example.a123456789_android_internet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ListViewImageWebActivity extends AppCompatActivity {
    ListView lv ;
    String[] strName = {"漢堡", "三明治", "豆漿", "米漿", "紅茶", "蛋餅"};
    int[] iPrice = {50, 45, 15, 15, 15, 25};
    String[] strPic = {
            "https://i.kfs.io/playlist/global/61763305v2/fit/500x500.jpg",
            "https://image.gameapps.hk/images/201709/10/nnn1.jpg",
            "https://assets.juksy.com/files/articles/94193/800x_100_w-5d71c106e738c.jpg",
            "https://ae01.alicdn.com/kf/U31ff823e57864899b42a6642de9accd12.jpg",
            "https://game.nownews.com/wp-content/uploads/2020/12/HHp2mS6-1024x741.jpg",
            "https://upload.wikimedia.org/wikipedia/zh/thumb/6/61/ONE_PIECE_Logo.svg/1200px-ONE_PIECE_Logo.svg.png"
    };
    ArrayList<HashMap<String, String>> arrayList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view_image_web);
        lv = (ListView) findViewById(R.id.lvWeb);
        for(int i=0; i<strName.length; i++){
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("name", strName[i]);
            hashMap.put("price",String.valueOf(iPrice[i]));
            hashMap.put("pic",strPic[i]);
            arrayList.add(hashMap);
        }
        CustomSimpleAdapter ap = new CustomSimpleAdapter(this, arrayList, R.layout.customerlayout,
                new String[]{"name", "price", "pic"},
                new int[]{R.id.cuslayout_name, R.id.cuslayout_price,R.id.cuslayout_iv});
        lv.setAdapter(ap);
    }

    class CustomSimpleAdapter extends SimpleAdapter {
        private List<? extends Map<String, ?>> mData;
        private int mResource;
        private LayoutInflater mInflater;
        private String[] mFrom;
        private int[] mTo;
        private ViewBinder mViewBinder;

        public CustomSimpleAdapter(Context context, List<? extends Map<String, ?>> data, int resource, String[] from, int[] to) {
            super(context, data, resource, from, to);
            mData = data;
            mResource = resource;
            mFrom = from;
            mTo = to;
            mInflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public View getView(int position, View recycled, ViewGroup container) {
            View v;
            if (recycled == null) {
                v = mInflater.inflate(mResource, container, false);
            } else {
                v =  recycled;
            }
            bindView(position, v);
            return v;
        }

        private void bindView(int position, View view) {
            final Map<String, ?> dataSet = mData.get(position);
            if (dataSet == null) {
                return;
            }
            final ViewBinder binder = mViewBinder;
            final String[] from = mFrom;
            final int[] to = mTo;
            final int count = to.length;
            for (int i = 0; i < count; i++) {
                final View v = view.findViewById(to[i]);
                if (v != null) {
                    final Object data = dataSet.get(from[i]);
                    String text = data == null ? "" : data.toString();
                    boolean bound = false;
                    if (binder != null) {
                        bound = binder.setViewValue(v, data, text);
                    }
                    if (!bound) {
                        if (v instanceof TextView) {
                            setViewText((TextView) v, text);
                        } else if (v instanceof ImageView) {
                            if (data instanceof Integer) {
                                setViewImage((ImageView) v, (Integer) data);
                            } else {
                                //setViewImage((ImageView) v, text);
                                Glide.with(getApplicationContext()).load(text).into((ImageView) v);
                            }
                        } else {
                            throw new IllegalStateException(
                                    v.getClass().getName()
                                            + " is not a "
                                            + " view that can be bounds by this SimpleAdapter");
                        }
                    }
                }
            }
        }
    }



}