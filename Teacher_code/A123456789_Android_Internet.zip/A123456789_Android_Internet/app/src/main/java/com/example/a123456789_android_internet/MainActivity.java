package com.example.a123456789_android_internet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnHtml, btnWebImage, btnLVWebImage, btnJson;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnHtml = (Button) findViewById(R.id. btnHTML);
        btnWebImage = (Button) findViewById(R.id.btnWebImage);
        btnLVWebImage = (Button) findViewById(R.id.btnLVWebImage);
        btnJson = (Button) findViewById(R.id.btnJson);
        btnHtml.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, HTMLActivity.class));
            }
        });
        btnWebImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ImageWebActivity.class));
            }
        });
        btnLVWebImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ListViewImageWebActivity.class));
            }
        });
        btnJson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, JSONActivity.class));
            }
        });
    }
}