package com.example.a123456789_toolbars;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnActionBar, btnToolBar, btnAppBar, btnCollapsingToolBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnActionBar = (Button) findViewById(R.id.btnActionBar);
        btnToolBar = (Button) findViewById(R.id.btnToolBar);
        btnAppBar = (Button) findViewById(R.id.btnAppBar);
        btnCollapsingToolBar = (Button) findViewById(R.id.btnCollapsingToolbar);
        btnActionBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ActionBarActivity.class);
                startActivity(intent);
            }
        });
        btnToolBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ToolbarActivity.class);
                startActivity(intent);
            }
        });
        btnAppBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AppBarActivity.class);
                startActivity(intent);
            }
        });
        btnCollapsingToolBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CollapsingToolbarActivity.class);
                startActivity(intent);
            }
        });
    }
}