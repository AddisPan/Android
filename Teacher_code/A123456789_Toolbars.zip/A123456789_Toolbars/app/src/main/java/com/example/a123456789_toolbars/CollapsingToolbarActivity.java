package com.example.a123456789_toolbars;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CollapsingToolbarActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collapsing_toolbar);
    }
}