package com.example.a123456789_recyclerview;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.SimpleAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.util.ArrayList;
import java.util.HashMap;

public class ImageDialogFragment extends DialogFragment {
    static String[] strName = {"漢堡", "三明治", "豆漿", "米漿", "紅茶", "蛋餅"};
    static int[] ipic = {R.drawable.a1, R.drawable.a2, R.drawable.a3, R.drawable.a4, R.drawable.a5, R.drawable.a6};
    static ArrayList<HashMap<String, String>> arrayList = new ArrayList<>();

    static{
        for(int i=0; i<strName.length; i++){
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("name", strName[i]);
            hashMap.put("pic",String.valueOf(ipic[i]));
            arrayList.add(hashMap);
        }
    }

    int position;
    ImageDialogFragment(int _position){
        position = _position;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        SimpleAdapter ap = new SimpleAdapter(getContext(), arrayList, R.layout.pic_text_layout,
                new String[]{"name", "pic"}, new int[]{R.id.layout_iv_text, R.id.layout_iv});
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setAdapter(ap, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //A123456789 劉嘉傑
                ((CustomerActivityUpdate) getContext()).ap.changePic(position, ipic[which]);
            }
        }).setNegativeButton("取消", null).setTitle("請選擇一張圖片");
        return builder.create();
    }
}
