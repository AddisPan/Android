package com.example.a123456789_listview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class SimpleListActivity extends AppCompatActivity {
    ListView lv1;
    String[] strData = {"基隆巿", "台北巿", "新北巿", "桃園巿", "新竹巿", "苗栗縣", "台中巿", "彰化縣", "南投縣", "雲林縣",
                        "嘉義縣", "台南巿", "高雄巿", "屏東縣", "宜蘭縣", "花蓮縣", "台東縣", "澎湖縣", "金門縣", "馬祖縣"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_list);
        lv1 = (ListView) findViewById(R.id.LV1);
        ArrayAdapter<String> ap = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,strData);
        lv1.setAdapter(ap);
    }
}