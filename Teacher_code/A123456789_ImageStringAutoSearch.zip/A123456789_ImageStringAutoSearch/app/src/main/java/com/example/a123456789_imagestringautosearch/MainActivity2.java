package com.example.a123456789_imagestringautosearch;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

public class MainActivity2 extends AppCompatActivity {
    AutoCompleteTextView autotv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        autotv = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView);
        String[] data = getResources().getStringArray(R.array.PlaceArray);
        ArrayAdapter<String> ap = new ArrayAdapter<>(this, R.layout.listview, data);
        autotv.setAdapter(ap);
    }
}