package com.example.a123456789_imagestringautosearch;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    ImageView iv;
    TextView tv;
    Button btnPre, btnNext;
    SeekBar seekBar;
    int[] images = {R.drawable.flow01b, R.drawable.flow02b, R.drawable.flow03b, R.drawable.flow04b, R.drawable.flow05b, R.drawable.flow06b};
    int iNow = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        InitialUI();
    }

    private void InitialUI() {
        iv = (ImageView) findViewById(R.id.imageView2);
        tv = (TextView) findViewById(R.id.textView);
        btnPre = (Button) findViewById(R.id.btnPre);
        btnNext = (Button) findViewById(R.id.btnNext);
        seekBar = (SeekBar) findViewById(R.id.seekBar);
        btnPre.setOnClickListener(btnPreNext);
        btnNext.setOnClickListener(btnPreNext);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                iv.setImageAlpha(255*progress/100);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
//                intent.setClass(MainActivity.this, MainActivity2.class);
                intent.setClass(getApplicationContext(), MainActivity2.class);
                startActivity(intent);
            }
        });
    }


    View.OnClickListener btnPreNext = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Button btn = (Button)v;
            if (btn.getText().equals("前一筆")){
                if (iNow > 0 ) iNow--;
            }else if (btn.getText().equals("下一筆")){
                if (iNow < images.length-1) iNow++;
            }
            iv.setImageResource(images[iNow]);
            tv.setText("總共有"+images.length+"筆, 這是第"+(iNow+1)+"筆");
        }
    };

}