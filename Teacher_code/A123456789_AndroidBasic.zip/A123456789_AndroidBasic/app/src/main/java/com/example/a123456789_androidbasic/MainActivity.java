package com.example.a123456789_androidbasic;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText etFirst, etSecond;
    Button btnAdd;
    TextView tvAddResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        etFirst = (EditText) findViewById(R.id.et1);
        etSecond = (EditText) findViewById(R.id.et2);
        btnAdd = (Button) findViewById(R.id.btnSum);
        tvAddResult = (TextView) findViewById(R.id.tvResult);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int i1 = Integer.parseInt(etFirst.getText().toString());
                int i2 = Integer.parseInt(etSecond.getText().toString());
//                tvAddResult.setText(""+(i1+i2));
                tvAddResult.setText(String.valueOf(i1+i2));
            }
        });
    }
}