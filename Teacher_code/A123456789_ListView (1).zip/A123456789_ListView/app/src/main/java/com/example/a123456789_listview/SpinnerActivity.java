package com.example.a123456789_listview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class SpinnerActivity extends AppCompatActivity {
    Spinner spStringArray, spSimpleList, spSimpleList2, spCustomer;
    String[] strData = {"基隆巿", "台北巿", "新北巿", "桃園巿", "新竹巿", "苗栗縣", "台中巿", "彰化縣", "南投縣", "雲林縣",
            "嘉義縣", "台南巿", "高雄巿", "屏東縣", "宜蘭縣", "花蓮縣", "台東縣", "澎湖縣", "金門縣", "馬祖縣"};
    int[] Person = {23, 33, 2234, 232, 223, 12, 5, 88, 99, 10,
            11, 22, 33, 44, 55, 66, 77, 88, 99, 100};

    String[] strName = {"漢堡", "三明治", "豆漿", "米漿", "紅茶", "蛋餅"};
    int[] iPrice = {50, 45, 15, 15, 15, 25};
    int[] ipic = {R.drawable.a1, R.drawable.a2, R.drawable.a3, R.drawable.a4, R.drawable.a5, R.drawable.a6};
    ArrayList<HashMap<String, String>> arrayList = new ArrayList<>();
    ArrayList<HashMap<String, String>> arrayList2 = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spinner);
        spStringArray = (Spinner) findViewById(R.id.spStringArray);
        spSimpleList = (Spinner) findViewById(R.id.spSimpleList);
        spSimpleList2 = (Spinner) findViewById(R.id.spSimpleList2);
        spCustomer = (Spinner) findViewById(R.id.spCustomer);

        spStringArray.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String[] strAry = getResources().getStringArray(R.array.s1);
                Toast.makeText(getApplicationContext(), strAry[position], Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        ArrayAdapter<String> ap = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,strData);
        spSimpleList.setAdapter(ap);

        spSimpleList.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), strData[position], Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        for(int i=0; i<strData.length; i++){
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("city", strData[i]);
            hashMap.put("person",String.valueOf(Person[i]));
            arrayList.add(hashMap);
        }
        SimpleAdapter ap2 = new SimpleAdapter(this, arrayList, android.R.layout.simple_list_item_2,
                new String[]{"city", "person"}, new int[]{android.R.id.text1, android.R.id.text2});
        spSimpleList2.setAdapter(ap2);

        spSimpleList2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                HashMap<String, String> hashMap = arrayList.get(position);
                String s = hashMap.get("city") + hashMap.get("person");
                Toast.makeText(getApplicationContext(), s , Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        for(int i=0; i<strName.length; i++){
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("name", strName[i]);
            hashMap.put("price",String.valueOf(iPrice[i]));
            hashMap.put("pic",String.valueOf(ipic[i]));
            arrayList2.add(hashMap);
        }
        SimpleAdapter ap3 = new SimpleAdapter(this, arrayList2, R.layout.customer_layout,
                new String[]{"name", "price", "pic"}, new int[]{R.id.cus_tv1, R.id.cus_tv2,R.id.cus_imageview});
        spCustomer.setAdapter(ap3);

        spCustomer.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                HashMap<String, String> hashMap = arrayList2.get(position);
                String s = hashMap.get("name") + hashMap.get("price");
                Toast.makeText(getApplicationContext(), s , Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}