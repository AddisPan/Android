package com.example.a123456789_listview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class SimpleListActivityUpdate extends AppCompatActivity {
    String[] data;
    ArrayList<String> arylist;
    LinearLayout ll;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_list_update);
        data = getIntent().getStringArrayExtra("data");
        arylist = new ArrayList<String>(Arrays.asList(data));
        Toast.makeText(getApplicationContext(), data[0], Toast.LENGTH_SHORT).show();

        InitialUI();
    }

    private void InitialUI() {
        ScrollView sv = new ScrollView(this);
        this.addContentView(sv, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.MATCH_PARENT));
        ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        sv.addView(ll,new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT));

        for(int i = 0; i< arylist.size(); i++){
            LinearLayout ll2 = new LinearLayout(this);
            ll2.setOrientation(LinearLayout.HORIZONTAL);
            ll.addView(ll2, new ViewGroup.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT));
            ll2.setWeightSum(6);

            EditText et = new EditText(this);
            et.setGravity(Gravity.CENTER);
            et.setText(arylist.get(i));
            ll2.addView(et, new LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.MATCH_PARENT, 5));
            Button btndel = new Button(this);
            btndel.setText("Del");
            ll2.addView(btndel, new LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.MATCH_PARENT, 1));
            btndel.setOnClickListener(new ClassButtonDel(i));
        }

        Button btnAdd = new Button(this);
        btnAdd.setGravity(Gravity.CENTER);
        btnAdd.setText("新增");
        ll.addView(btnAdd, new ViewGroup.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

    }


    class ClassButtonDel implements View.OnClickListener{
        int position;
        ClassButtonDel(int _position){
            position = _position;
        }

        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), arylist.get(position), Toast.LENGTH_SHORT).show();
        }
    }


}
