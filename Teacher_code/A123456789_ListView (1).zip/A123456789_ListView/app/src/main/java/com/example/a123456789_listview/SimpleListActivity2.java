package com.example.a123456789_listview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;

public class SimpleListActivity2 extends AppCompatActivity {
    ListView lv2;
    String[] strData = {"基隆巿", "台北巿", "新北巿", "桃園巿", "新竹巿", "苗栗縣", "台中巿", "彰化縣", "南投縣", "雲林縣",
            "嘉義縣", "台南巿", "高雄巿", "屏東縣", "宜蘭縣", "花蓮縣", "台東縣", "澎湖縣", "金門縣", "馬祖縣"};
    int[] Person = {23, 33, 2234, 232, 223, 12, 5, 88, 99, 10,
            11, 22, 33, 44, 55, 66, 77, 88, 99, 100};
    ArrayList<HashMap<String, String>> arrayList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_list2);
        lv2 = (ListView) findViewById(R.id.LV2);
        for(int i=0; i<strData.length; i++){
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("city", strData[i]);
            hashMap.put("person",String.valueOf(Person[i]));
            arrayList.add(hashMap);
        }
        SimpleAdapter ap = new SimpleAdapter(this, arrayList, android.R.layout.simple_list_item_2,
                new String[]{"city", "person"}, new int[]{android.R.id.text1, android.R.id.text2});
        lv2.setAdapter(ap);
    }
}