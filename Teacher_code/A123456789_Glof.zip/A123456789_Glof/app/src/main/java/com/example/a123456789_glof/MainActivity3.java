package com.example.a123456789_glof;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {
    Button btnSum, btnAdd;
    TextView tvResult;
    LinearLayout ll;
    int icount = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        fnInitialUI();
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                EditText et = new EditText(MainActivity3.this);
                EditText et = new EditText(getApplicationContext());
                et.setGravity(Gravity.CENTER);
                et.setInputType(InputType.TYPE_CLASS_NUMBER);
                et.setHint("第"+(icount+1)+"洞");
                ll.addView(et, icount, new ViewGroup.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT));
                icount++;
            }
        });
        btnSum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int iSum = 0;
                for(int i=0 ; i<ll.getChildCount() ; i++){
                    if (ll.getChildAt(i) instanceof EditText ){
                        EditText et = (EditText) ll.getChildAt(i);
                        try{
                            iSum += Integer.parseInt(et.getText().toString());
                        }catch (Exception e){
                        }
                    }
                }
                tvResult.setText("合計："+String.valueOf(iSum));
            }
        });
    }

    private void fnInitialUI() {
        ScrollView sv = new ScrollView(this);
        this.addContentView(sv, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.MATCH_PARENT));
        ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        sv.addView(ll,new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT));

        EditText et = new EditText(this);
        et.setGravity(Gravity.CENTER);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setHint("第1洞");
        ll.addView(et, new ViewGroup.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        LinearLayout ll2 = new LinearLayout(this);
        ll2.setOrientation(LinearLayout.HORIZONTAL);
        ll.addView(ll2,new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        btnAdd = new Button(this);
        ll2.addView(btnAdd, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT, 4));
        btnAdd.setText("+");
        btnSum = new Button(this);
        ll2.addView(btnSum, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        btnSum.setText("Sum");

        tvResult =new TextView(this);
        tvResult.setGravity(Gravity.CENTER);
        tvResult.setTextSize(28);
        ll.addView(tvResult, new ViewGroup.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
    }
}