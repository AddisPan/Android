package com.example.a123456789_listview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class CustomerActivity extends AppCompatActivity {
    ListView lv3;
    String[] strName = {"漢堡", "三明治", "豆漿", "米漿", "紅茶", "蛋餅"};
    int[] iPrice = {50, 45, 15, 15, 15, 25};
    int[] ipic = {R.drawable.a1, R.drawable.a2, R.drawable.a3, R.drawable.a4, R.drawable.a5, R.drawable.a6};
    ArrayList<HashMap<String, String>> arrayList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer);
        lv3 = (ListView) findViewById(R.id.LV3);
        for(int i=0; i<strName.length; i++){
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("name", strName[i]);
            hashMap.put("price",String.valueOf(iPrice[i]));
            hashMap.put("pic",String.valueOf(ipic[i]));
            arrayList.add(hashMap);
        }
        SimpleAdapter ap = new SimpleAdapter(this, arrayList, R.layout.customer_layout,
                new String[]{"name", "price", "pic"}, new int[]{R.id.cus_tv1, R.id.cus_tv2,R.id.cus_imageview});
        lv3.setAdapter(ap);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_customer, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int getId = item.getItemId();
        switch (getId){
            case R.id.menu_customer_update:
                Intent intent = new Intent(getApplicationContext(), CustomerActivityUpdate.class);
                intent.putExtra("data", arrayList);
                startActivityForResult(intent,3);
                break;
            case R.id.menu_customer_about_me:
                Toast.makeText(getApplicationContext(), "你好,我是A123456789", Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

}