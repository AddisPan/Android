package com.example.a123456789_listview;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class CustomerActivityUpdate extends AppCompatActivity {
    ArrayList<HashMap<String, String>> arylist;
    LinearLayout ll;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_update);
        arylist = (ArrayList<HashMap<String, String>>) getIntent().getSerializableExtra("data");
        InitialUI();
    }

    private void InitialUI() {
        ScrollView sv = new ScrollView(this);
        this.addContentView(sv, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.MATCH_PARENT));
        ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        sv.addView(ll,new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT));

        reloadUI();
    }

    public void reloadUI(){
        ll.removeAllViews();
        for(int i = 0; i< arylist.size(); i++){
            LinearLayout ll2 = new LinearLayout(this);
            ll2.setOrientation(LinearLayout.HORIZONTAL);
            ll.addView(ll2, new ViewGroup.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    150));
            ll2.setWeightSum(10);

            EditText et = new EditText(this);
            et.setGravity(Gravity.CENTER);
            et.setText(arylist.get(i).get("name"));
            ll2.addView(et, new LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.MATCH_PARENT, 3));

            et = new EditText(this);
            et.setGravity(Gravity.CENTER);
            et.setText(arylist.get(i).get("price"));
            ll2.addView(et, new LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.MATCH_PARENT, 3));

            ImageView iv = new ImageView(this);
            iv.setImageResource(Integer.parseInt(arylist.get(i).get("pic")));
            ll2.addView(iv, new LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.MATCH_PARENT, 3));

            Button btndel = new Button(this);
            btndel.setText("Del");
            ll2.addView(btndel, new LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.MATCH_PARENT, 1));
            btndel.setOnClickListener(new ClassButtonDel(i));
        }

        Button btnAdd = new Button(this);
        btnAdd.setGravity(Gravity.CENTER);
        btnAdd.setText("新增");
        ll.addView(btnAdd, new ViewGroup.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LinearLayout ll2 = new LinearLayout(getApplicationContext());
                ll2.setOrientation(LinearLayout.HORIZONTAL);
                ll.addView(ll2, arylist.size() ,new ViewGroup.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        150));
                ll2.setWeightSum(10);

                EditText et = new EditText(getApplicationContext());
                et.setGravity(Gravity.CENTER);
                et.setText("");
                ll2.addView(et, new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT, 3));

                et = new EditText(getApplicationContext());
                et.setGravity(Gravity.CENTER);
                et.setText("");
                ll2.addView(et, new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT, 3));

                ImageView iv = new ImageView(getApplicationContext());
                iv.setImageResource(R.drawable.ic_launcher_background);
                ll2.addView(iv, new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT, 3));

                Button btndel = new Button(getApplicationContext());
                btndel.setText("Del");
                ll2.addView(btndel, new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT, 1));
                btndel.setOnClickListener(new ClassButtonDel(arylist.size()-1));
            }
        });
    }


    class ClassButtonDel implements View.OnClickListener{
        int position;
        ClassButtonDel(int _position){
            position = _position;
        }

        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), arylist.get(position).get("name"), Toast.LENGTH_SHORT).show();
            AlertDialog.Builder builder = new AlertDialog.Builder(CustomerActivityUpdate.this);
            builder.setMessage("確定刪除這筆資料 ?").setPositiveButton("確定", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    arylist.remove(position);
//                    reloadUI();
                    ll.removeViewAt(position);
                }
            }).setNegativeButton("取消", null).show();
        }
    }

}