package com.example.a123456789_listview;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class SimpleListActivityUpdate extends AppCompatActivity {
    String[] data;
    ArrayList<String> arylist;
    LinearLayout ll;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_list_update);
        data = getIntent().getStringArrayExtra("data");
        arylist = new ArrayList<String>(Arrays.asList(data));
//        Toast.makeText(getApplicationContext(), data[0], Toast.LENGTH_SHORT).show();
        InitialUI();
    }

    @Override
    public void onBackPressed() {
        for(int i=0 ; i < arylist.size(); i++){
            arylist.set(i,((EditText)((LinearLayout)ll.getChildAt(i)).getChildAt(0)).getText().toString());
        }
        String[] aryString = arylist.toArray(new String[0]);
        getIntent().putExtra("Result", aryString);
        setResult(999,getIntent());
        super.onBackPressed();
//        View v = ll.getChildAt(0);
//        if (v instanceof LinearLayout){
//            View v2 = ((LinearLayout) v).getChildAt(0);
//            if (v2 instanceof  EditText){
//                Toast.makeText(getApplicationContext(), ((EditText) v2).getText().toString(), Toast.LENGTH_SHORT).show();
//            }
//        }
    }



    private void InitialUI() {
        ScrollView sv = new ScrollView(this);
        this.addContentView(sv, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.MATCH_PARENT));
        ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        sv.addView(ll,new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT));

        reloadUI();
    }

    public void reloadUI(){
        ll.removeAllViews();
        for(int i = 0; i< arylist.size(); i++){
            LinearLayout ll2 = new LinearLayout(this);
            ll2.setOrientation(LinearLayout.HORIZONTAL);
            ll.addView(ll2, new ViewGroup.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT));
            ll2.setWeightSum(6);

            EditText et = new EditText(this);
            et.setGravity(Gravity.CENTER);
            et.setText(arylist.get(i));
            ll2.addView(et, new LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.MATCH_PARENT, 5));
            Button btndel = new Button(this);
            btndel.setText("Del");
            ll2.addView(btndel, new LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.MATCH_PARENT, 1));
            btndel.setOnClickListener(new ClassButtonDel(i));
        }

        Button btnAdd = new Button(this);
        btnAdd.setGravity(Gravity.CENTER);
        btnAdd.setText("新增");
        ll.addView(btnAdd, new ViewGroup.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LinearLayout ll2 = new LinearLayout(getApplicationContext());
                ll2.setOrientation(LinearLayout.HORIZONTAL);
                ll.addView(ll2, arylist.size() ,new ViewGroup.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT));
                ll2.setWeightSum(6);

                EditText et = new EditText(getApplicationContext());
                et.setGravity(Gravity.CENTER);
                et.setText("");
                arylist.add("");
                ll2.addView(et, new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT, 5));
                Button btndel = new Button(getApplicationContext());
                btndel.setText("Del");
                ll2.addView(btndel, new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT, 1));
                btndel.setOnClickListener(new ClassButtonDel(arylist.size()-1));
            }
        });
    }

    class ClassButtonDel implements View.OnClickListener{
        int position;
        ClassButtonDel(int _position){
            position = _position;
        }

        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), arylist.get(position), Toast.LENGTH_SHORT).show();
            AlertDialog.Builder builder = new AlertDialog.Builder(SimpleListActivityUpdate.this);
            builder.setMessage("確定刪除這筆資料 ?").setPositiveButton("確定", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    arylist.remove(position);
//                    reloadUI();
                    ll.removeViewAt(position);
                }
            }).setNegativeButton("取消", null).show();
        }
    }


}
