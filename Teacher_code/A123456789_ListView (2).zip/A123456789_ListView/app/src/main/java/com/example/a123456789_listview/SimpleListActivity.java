package com.example.a123456789_listview;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class SimpleListActivity extends AppCompatActivity {
    ListView lv1;
    String[] strData = {"基隆巿", "台北巿", "新北巿", "桃園巿", "新竹巿", "苗栗縣", "台中巿", "彰化縣", "南投縣", "雲林縣",
                        "嘉義縣", "台南巿", "高雄巿", "屏東縣", "宜蘭縣", "花蓮縣", "台東縣", "澎湖縣", "金門縣", "馬祖縣"};
    ArrayAdapter<String> ap;
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
//        Toast.makeText(getApplicationContext(), "ABC"+resultCode, Toast.LENGTH_SHORT).show();
        if (requestCode == 1 && resultCode == 999){
            strData = data.getStringArrayExtra("Result");
            ap = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,strData);
            lv1.setAdapter(ap);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_list);
        lv1 = (ListView) findViewById(R.id.LV1);
        ap = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,strData);
        lv1.setAdapter(ap);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_simplelist, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int getId = item.getItemId();
        switch (getId){
            case R.id.menu_update:
                Intent intent = new Intent(getApplicationContext(), SimpleListActivityUpdate.class);
                intent.putExtra("data", strData);
                startActivityForResult(intent,1);
                break;
            case R.id.menu_about_me:
                Toast.makeText(getApplicationContext(), "你好,我是A123456789", Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }


}